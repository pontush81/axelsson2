# Kan jag se information om mitt schema i mobilen?

**Datum:** den 22 augusti 2025  
**Kategori:** Time  
**Underkategori:** Schema & Planering  
**Typ:** faq  
**Svårighetsgrad:** intermediate  
**Tags:** mobil, ob, schema, övertid  
**Bilder:** 3  
**URL:** https://knowledge.flexapplications.se/kan-jag-se-information-om-mitt-schema-i-mobilen

---

HRM Mobile - Mitt schema
I
HRM Mobile
finns vyn
Mitt schema.
Där visas schemat veckovis. Du kan bläddra mellan veckor med pilarna eller klicka på veckonumret för att välja ett annat.
![ikon Mitt schema](images/kan-jag-se-information-om-mitt-schema-i-mobilen_c17cd78d.jpg)
![Mitt schema visar schema för en vecka.](images/kan-jag-se-information-om-mitt-schema-i-mobilen_5198685c.jpg)
Klicka på en dag för att se detaljer som raster, planering, planerad övertid.
![Mitt schema visar schema för en dag.](images/kan-jag-se-information-om-mitt-schema-i-mobilen_a8e83030.jpg)
