# Checklista vid årsskifte i Flex HRM Payroll

**Datum:** den 13 februari 2026  
**Kategori:** Systemgemensamt  
**Underkategori:** Användare & Behörighet  
**Typ:** other  
**Svårighetsgrad:** intermediate  
**Tags:** roll  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/sv/checklista-vid-%C3%A5rsskifte-i-flex-hrm-payroll

---

Kontrollera
avvikelsedagar
för det nya året.
Gör färdigt och avräkna alla löneutbetalningar för det gamla året.
Kontrollera att du har versionen som är förberedd för det nya året.
Kör
FOS-rutinen
för att uppdatera skatteuppgifterna på de anställda.
Hämta
skattetabeller
för det nya året.
Kontrollera att
Belopp och Procent
har hämtats för det nya året.
Nu är allt klart för att skapa lönekörningen för utbetalning i januari.
Du som har HRM Payroll behöver uppdatera till ny version för att kunna betala ut lön för år 2026 (Version 2026.1).
Har ditt företag drift i vår driftmiljö med automatiska uppdateringar får ni versionen automatiskt.
Har ditt företag egen drift hos vår driftleverantör Iver eller egen lokal drift behöver du installera en uppdatering eller boka en teknisk konsult för uppdatering via konsultbokningen. Båda tjänsterna når du via
Serviceportalen
.
Nya lagar och regler 2026 – så påverkas du som jobbar med HR och lön
