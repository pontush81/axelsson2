# ⚙️Kan man överföra saldovärden till lön?

**Datum:** den 26 september 2025  
**Kategori:** Time  
**Underkategori:** Lön & Överföring  
**Typ:** config  
**Svårighetsgrad:** intermediate  
**Tags:** lön, saldo, tidrapport  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/sv/kan-man-%C3%B6verf%C3%B6ra-saldov%C3%A4rden-till-l%C3%B6n

---

Saldovärden överförs till lön om du anger en löneart under
Inställningar > Saldon > Definiera saldon.
För periodbundna saldon, som närvaro, överförs alltid periodens värde. För rullande saldon, som inte bryts vid periodens slut, kan du välja om du vill överföra periodens värde, alltså det som hänt i saldot under perioden, eller om du vill överföra ingående eller utgående värde. Valet är beroende av hur det mottagande lönesystemet vill ha det.
Om ett saldo inte överförs till lön trots att det finns en löneart: Kontrollera
datumen
för överföring. När man överför saldon vill man överföra en period i taget. Om man istället för att överföra 1-30 april överför 1 mars-30 april för att få med sent granskade tidrapporter får man inte något periodens värde för saldon eftersom det inte är en period. Överföringen kan inte heller ta med ingående eller utgående värde då det finns flera sådana värden i datumintervallet.
