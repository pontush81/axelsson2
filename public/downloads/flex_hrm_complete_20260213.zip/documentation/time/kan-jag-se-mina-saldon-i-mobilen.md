# Kan jag se mina saldon i mobilen?

**Datum:** den 22 augusti 2025  
**Kategori:** Time  
**Underkategori:** Mobil & Stämpling  
**Typ:** faq  
**Svårighetsgrad:** intermediate  
**Tags:** frånvaro, mobil, ob, saldo, schema, tidrapport  
**Bilder:** 2  
**URL:** https://knowledge.flexhrm.com/sv/kan-jag-se-mina-saldon-i-mobilen

---

HRM Mobile - Tidsaldon
I
HRM Mobile
, funktionen
Tidsaldon
ser du periodens summeringar. Samtliga periodsaldon som visas i tidrapporten i HRM visas också här. Du kan bläddra mellan perioder, eller klicka på inladdad period för att byta till en annan.
![Ikon Tidsaldon](images/kan-jag-se-mina-saldon-i-mobilen_a5f34d34.jpg)
![Tidsaldon. Vyn visar period 202507. Närvaro, Frånvaro, Summa registrerad tid, Ospecad närvaro, Ospecad frånvaro, Schematid samt Flextid  (ingående, periodens värde och utgående).](images/kan-jag-se-mina-saldon-i-mobilen_cbd07d19.jpg)
För att se varje dags saldon kan du använda daginformationen i funktionen
Tidrapport.
Relaterat:
Hur tidrapporterar jag i mobilen?
