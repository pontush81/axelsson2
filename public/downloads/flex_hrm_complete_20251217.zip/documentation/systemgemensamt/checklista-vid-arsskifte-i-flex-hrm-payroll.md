# Checklista vid årsskifte i Flex HRM Payroll

**Datum:** den 18 november 2025  
**Kategori:** Systemgemensamt  
**Underkategori:** Användare & Behörighet  
**Typ:** other  
**Svårighetsgrad:** beginner  
**Tags:** roll  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/checklista-vid-%C3%A5rsskifte-i-flex-hrm-payroll

---

Kontrollera
avvikelsedagar
för det nya året.
Gör färdigt och avräkna alla löneutbetalningar för det gamla året.
Kontrollera att du har versionen som är förberedd för det nya året.
Kör
FOS-rutinen
för att uppdatera skatteuppgifterna på de anställda.
Hämta
skattetabeller
för det nya året.
Kontrollera att
Belopp och Procent
har hämtats för det nya året.
Nu är allt klart för att skapa lönekörningen för utbetalning i januari.
