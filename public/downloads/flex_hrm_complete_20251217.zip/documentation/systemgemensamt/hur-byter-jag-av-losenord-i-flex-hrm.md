# Hur byter jag av lösenord i Flex HRM?

**Datum:** den 3 december 2025  
**Kategori:** Systemgemensamt  
**Underkategori:** Mobil  
**Typ:** howto  
**Svårighetsgrad:** beginner  
**Tags:** mobil  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/byte-av-losenord

---

Denna artikel beskriver hur du byter ditt lösenord.
Eftersom du loggar in i Flex HRM med Visma Connect, byter du inte lösenordet direkt i Flex HRM. Istället gör du det i Visma Connect.
Du kommer åt ditt Visma Connect-konto på följande sätt:
I Flex HRM:
Gå till
Min profil > Kontoinställningar
.
I HRM Mobile:
Gå till
Inställningar > Visma Connect
.
