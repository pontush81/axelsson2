# Mina kollegor - Var hittar jag information om mina kollegor?

**Datum:** den 7 augusti 2025  
**Kategori:** Systemgemensamt  
**Underkategori:** Mobil  
**Typ:** other  
**Svårighetsgrad:** intermediate  
**Tags:** mobil  
**Bilder:** 3  
**URL:** https://knowledge.flexhrm.com/mina-kollegor-var-kan-jag-se-information-om-mina-kollegor

---

Mina kollegor - HRM Mobile
![Bild](images/mina-kollegor-var-hittar-jag-information-om-mina-kollegor_f6716f70.png)
Funktionen Mina kollegor i appen HRM Mobile fungerar både som närvarotablå och kontaktinformation till dina kollegor.
![Bild](images/mina-kollegor-var-hittar-jag-information-om-mina-kollegor_6057e5f7.png)
![Bild](images/mina-kollegor-var-hittar-jag-information-om-mina-kollegor_01020a05.png)
Relaterade artiklar:
Kan jag se information om mitt schema i mobilen?
Kan jag se mina saldon i mobilen?
