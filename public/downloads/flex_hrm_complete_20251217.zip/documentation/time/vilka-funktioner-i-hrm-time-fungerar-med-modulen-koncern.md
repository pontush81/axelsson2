# Vilka funktioner i HRM Time fungerar med modulen Koncern?

**Datum:** den 29 september 2025  
**Kategori:** Time  
**Underkategori:** Frånvaro & Semester  
**Typ:** feature  
**Svårighetsgrad:** advanced  
**Tags:** attestering, frånvaro, hrm-time, övertid  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/vilka-funktioner-i-hrm-time-fungerar-med-modulen-koncern

---

En kort sammanfattning av vilka rapporter och andra funktioner som fungerar med modulen "Koncernhantering" i HRM Time
Vad ingår i koncernhanteringen?
Dashboard:
Sjukfrånvaro
Startsida
: Närvarotablå, Organisationsöversikt, Påminnelser, Övertidsbevakning.
Granskning
: Attesteringvyn
Standardrapporter
: Frånvarostatistik, Fördelning av tid och Personallista
Rapportgeneratorn:
Datakällorna Anställda, Tidtransaktioner och arbetspass.
Anställdaregistret:
Anställningsdatum inom koncern - syns på den aktuella anställningen.
Möjlighet att hämta ledigt anställningsnr inom koncern (samt en anställd kan ha samma anställningsnr i två bolag så länge den även har samma personnr)
