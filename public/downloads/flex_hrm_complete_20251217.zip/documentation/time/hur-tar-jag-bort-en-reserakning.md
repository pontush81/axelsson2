# Hur tar jag bort en reseräkning?

**Datum:** den 5 december 2025  
**Kategori:** Time  
**Underkategori:** Övertid & Ersättning  
**Typ:** howto  
**Svårighetsgrad:** intermediate  
**Tags:** ob  
**Bilder:** 4  
**URL:** https://knowledge.flexhrm.com/hur-tar-jag-bort-en-tidrapport-0

---

Test
I reseräkningen kan du man dls ta bort enstaka transaktioner på en reseräkning alternativt ta bort hela reseräkningen.
För att ta bort enstaka transaktioner så väljer man att klicka på ikonen "Redigera utlägg/resa/" och sedan välja "Ta bort"
![Bild](images/hur-tar-jag-bort-en-reserakning_7c5c2959.png)
![Bild](images/hur-tar-jag-bort-en-reserakning_3239bb48.png)
För att ta bort hela reseräkningen så väljer man i meny
Mer
funktionen
Ta bort reseräkning.
![Bild](images/hur-tar-jag-bort-en-reserakning_503e0218.png)
Vill du rensa ett större urval av reseräkningar kan du använda funktionen
Borttag av reseräkningar.
Denna funktion används för att permanent radera reseräkningar enligt urval. Med denna funktion raderar systemet reseräkningen och sedan kan man lägga ut en ny för samma period.
I vyn
Borttag av reseräkningar
kan du göra urval på specifika anställningsnummer.
![Bild](images/hur-tar-jag-bort-en-reserakning_78d6e63a.png)
Observera
Var noga med urvalet, det går inte att ångra ett borttag av reseräkningar.
Vi rekommenderar att stora urval körs vid tider då få arbetar i HRM, eftersom det kan påverka prestandan.
