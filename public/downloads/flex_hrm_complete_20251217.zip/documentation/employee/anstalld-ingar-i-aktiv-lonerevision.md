# Anställd ingår i aktiv Lönerevision

**Datum:** den 24 september 2025  
**Kategori:** Employee  
**Underkategori:** Anställningshantering  
**Typ:** other  
**Svårighetsgrad:** beginner  
**Tags:** lönerevision  
**Bilder:** 1  
**URL:** https://knowledge.flexhrm.com/anstalld-ingar-i-aktiv-lonerevision

---

För att uppmärksamma att en anställd ingår i en aktiv lönerevision, d.v.s. där den anställdes nya lön inte blivit verkställd, visas nedan information i sidomenyn Lön i anställdaregistret
![Bild](images/anstalld-ingar-i-aktiv-lonerevision_7254eef6.png)
En anställd kan endast vara med i en lönerevision för samma år.
