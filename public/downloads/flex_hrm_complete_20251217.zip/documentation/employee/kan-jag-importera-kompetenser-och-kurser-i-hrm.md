# Kan jag importera Kompetenser och kurser i HRM?

**Datum:** den 5 november 2025  
**Kategori:** Employee  
**Underkategori:** Kompetens & Kurser  
**Typ:** faq  
**Svårighetsgrad:** intermediate  
**Tags:** kompetens, kurs  
**Bilder:** 0  
**URL:** https://knowledge.flexhrm.com/import-kompetenser-kurser-0

---

Denna artikel innehåller vanliga frågor för kompetenser och kurser i HRM
Kan jag importera in register för kompetens och kurser i HRM?
Nej, idag kan du inte importera in registren för kompetenser och kurser i HRM.
Kan jag importera in kompetenser och kurser på anställda i HRM?
Ja, du kan göra en import på kompetenser och kurser på anställda. Du behöver först skapa en importmall och gör sedan importen via
Bearbetningar > Servicerutiner > Import
.
För att kunna göra import på kompetenser krävs att
Kod
är satt i registret för kompetensen.
För import på kurser krävs att du satt
Kursnummer
och
Kurstillfällenummer
på kurserna i registret för kurser.
