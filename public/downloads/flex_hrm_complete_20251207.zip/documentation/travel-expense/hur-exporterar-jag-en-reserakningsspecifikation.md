# Hur exporterar jag en reseräkningsspecifikation?

**Datum:** den 2 oktober 2025  
**Kategori:** Travel & Expense  
**Underkategori:** Reseräkningar  
**Typ:** howto  
**Svårighetsgrad:** intermediate  
**Tags:** bil  
**Bilder:** 3  
**URL:** https://knowledge.flexapplications.se/reser%C3%A4kningsspecifikation-hur-exporterar-man-en-reser%C3%A4kningsspecifikation

---

För att skriva ut din reseräkningsspecifikation, använd knappen:
![Bild](images/hur-exporterar-jag-en-reserakningsspecifikation_cf342007.png)
Utskriften öppnas i en ny flik, varifrån du sedan kan exportera den vidare eller skriva ut den på papper.
![Bild](images/hur-exporterar-jag-en-reserakningsspecifikation_73169ed9.png)
Totalsummor av alla delar visas alltid på sista sidan under ”Sammandrag reseräkning” eller före bilagor om du valt utskrift med bilagor.
![Bild](images/hur-exporterar-jag-en-reserakningsspecifikation_871b0530.png)
