# Hur byter jag språk i Flex HRM?

**Datum:** den 7 november 2025  
**Kategori:** Systemgemensamt  
**Underkategori:** Mobil  
**Typ:** howto  
**Svårighetsgrad:** intermediate  
**Tags:** mobil  
**Bilder:** 5  
**URL:** https://knowledge.flexapplications.se/byt-sprak-flex-hrm-0

---

Denna artikel beskriver hur du byter språk.
När du ska logga in i Flex HRM kan du välja språk vid inloggning. Längst ned ser du valt språk:
![Bild](images/hur-byter-jag-sprak-i-flex-hrm_f19249ce.png)
Du kan byta språk inne i Flex HRM via
Min profil - Språk och nationella inställningar
.
![Bild](images/hur-byter-jag-sprak-i-flex-hrm_26462473.png)
Välj önskat
språk
och
spara
din inställning.
![Bild](images/hur-byter-jag-sprak-i-flex-hrm_6ea5216d.png)
HRM Mobile
I
HRM Mobile
byter du språk via
Inställningar
och byt
språk
.
![Bild](images/hur-byter-jag-sprak-i-flex-hrm_f83a77fc.png)
![Bild](images/hur-byter-jag-sprak-i-flex-hrm_52a68d62.png)
